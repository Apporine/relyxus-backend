"""The client (09-sdks.md sections 1 to 4). A port of sdks/node/src/veryion.ts.

Verification is local and never does I/O; activation, check in and deactivation call the API. Nothing here reads a
licence key back out of storage. The API is synchronous: init() collects the fingerprint and reads storage, then
verify() answers from memory.
"""
from __future__ import annotations

import base64
import calendar
import hashlib
import json
import os
import random
import re
import socket
import sys
import threading
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any, Callable, Dict, List, Mapping, Optional, Union

from .core.base64url import decode_base64url_strict
from .core.jsvalues import is_js_number, js_number, js_trim, parse_time
from .core.licence_key import is_valid_licence_key
from .core.verify import apply_key_set, parse_token, verify_licence
from .errors import VeryionError
from .fingerprint import COMPONENTS, Fingerprint, collect_fingerprint
from .legacy import activate_key_fields
from .named import user_hash
from .offline import (
    OfflineRelease,
    OfflineRequest,
    build_offline_release,
    build_offline_request,
    new_release_secret,
    split_offline_response,
)
from .storage import FileStorage, MemoryStorage, Storage

SDK_VERSION = "1.1.0"
SDK_NAME = f"python {SDK_VERSION}"
CHECK_IN_FIRST_MS = 30_000
HOUR_MS = 3_600_000
# 09 section 3: after an offline check in, automatic retries follow at 15 minutes, 1 hour, then every 6 hours.
OFFLINE_RETRY_MS = (15 * 60_000, HOUR_MS, 6 * HOUR_MS)
_PRODUCT = re.compile(r"[A-Z][A-Z0-9]{1,5}")


# ---------------------------------------------------------------------------------------------------------------- HTTP


@dataclass
class HttpResponse:
    """What a transport gives back. Header names are matched without regard to case."""

    status: int
    text: str
    headers: Mapping[str, str] = field(default_factory=dict)

    def header(self, name: str) -> Optional[str]:
        lowered = name.lower()
        for key, value in self.headers.items():
            if key.lower() == lowered:
                return value
        return None


# A transport posts the body and returns the answer. It raises TimeoutError (or socket.timeout) when the server does not
# answer in time, and any other exception (OSError, urllib.error.URLError) when it cannot be reached.
Transport = Callable[[str, bytes, Mapping[str, str], float], HttpResponse]


def urllib_transport(url: str, body: bytes, headers: Mapping[str, str], timeout: float) -> HttpResponse:
    """The default transport: the standard library only, so installs need no extra packages."""
    request = urllib.request.Request(url, data=body, headers=dict(headers), method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return HttpResponse(status=response.status, text=response.read().decode("utf-8", errors="replace"), headers=dict(response.headers.items()))
    except urllib.error.HTTPError as error:
        text = error.read().decode("utf-8", errors="replace") if error.fp is not None else ""
        return HttpResponse(status=error.code, text=text, headers=dict(error.headers.items()) if error.headers else {})
    except urllib.error.URLError as error:
        if isinstance(error.reason, (socket.timeout, TimeoutError)):
            raise TimeoutError(str(error.reason)) from error
        raise


def map_code(status: int, server_code: Optional[str]) -> str:
    """The server's codes mapped to the SDK's (section 1.2)."""
    if server_code == "device_unidentifiable":
        return "device_unidentifiable"
    if server_code == "device_mismatch":
        return "device_mismatch"
    if server_code == "test_device_in_production":
        return "test_device_in_production"
    if server_code == "invalid_licence_key":
        return "invalid_licence_key"
    if server_code == "activation_not_found":
        return "activation_not_found"
    if status == 404:
        return "licence_not_found"
    if status == 403:
        return "licence_not_active"
    if status == 409:
        return "device_limit_reached"
    if status == 429:
        return "rate_limited"
    return "server_error"


# ------------------------------------------------------------------------------------------------------------- helpers


def _payload_of(token: Optional[str]) -> Optional[Dict[str, Any]]:
    """The payload of a token, read without checking it (only after the token was verified)."""
    if not token or not isinstance(token, str):
        return None
    parts = token.split(".")
    if len(parts) < 2 or not parts[1]:
        return None
    data = decode_base64url_strict(parts[1])
    if not data:
        return None
    try:
        value = json.loads(data.decode("utf-8", errors="replace"))
    except ValueError:
        return None
    return value if isinstance(value, dict) else None


def _utc(at: datetime) -> datetime:
    return at.replace(tzinfo=timezone.utc) if at.tzinfo is None else at.astimezone(timezone.utc)


def _ms(at: datetime) -> int:
    at = _utc(at)
    return calendar.timegm(at.utctimetuple()) * 1000 + at.microsecond // 1000


def _iso(at: datetime) -> str:
    return _utc(at).strftime("%Y-%m-%dT%H:%M:%SZ")


def _from_ms(ms: float) -> datetime:
    return datetime.fromtimestamp(ms / 1000.0, tz=timezone.utc)


def _check_in_hours(token: Optional[str]) -> Optional[Union[int, float]]:
    value = (_payload_of(token) or {}).get("checkInHours")
    return value if is_js_number(value) else None


def _vendor_of(keys: Union[str, Mapping[str, str]], product: str) -> tuple:
    if isinstance(keys, str):
        if not keys.startswith("vyk1."):
            raise VeryionError("invalid_config", "keys must be a key set token (vyk1) or a dict of public keys.")
        payload = _payload_of(keys)
        if not payload or payload.get("product") != product or not payload.get("keys") or not isinstance(payload.get("keys"), dict):
            raise VeryionError("invalid_config", "The key set does not belong to this product.")
        candidate: Dict[str, Optional[str]] = {}
        for kid, entry in payload["keys"].items():
            if isinstance(entry, dict) and "revokedAt" not in entry:
                candidate[kid] = entry.get("publicKey")
        checked = parse_token(keys, "vyk1", candidate)
        if checked.error:
            raise VeryionError("invalid_config", "The key set token does not verify under its own keys.")
        organisation = payload.get("organisation")
        return candidate, "" if organisation is None else str(organisation)
    if not isinstance(keys, Mapping):
        raise VeryionError("invalid_config", "keys must be a key set token (vyk1) or a dict of public keys.")
    if len(keys) == 0:
        raise VeryionError("invalid_config", "keys must not be empty.")
    for kid, value in keys.items():
        data = decode_base64url_strict(value) if isinstance(value, str) else None
        if not data or len(data) != 32:
            raise VeryionError("invalid_config", f"The public key {kid} is not a 32 byte base64url key.")
    first = sorted(keys)[0]
    return dict(keys), hashlib.sha256(first.encode("utf-8")).hexdigest()[:8]


# -------------------------------------------------------------------------------------------------------------- results


@dataclass(frozen=True)
class Customer:
    id: Optional[str]
    name: Optional[str]


@dataclass(frozen=True)
class Edition:
    code: Optional[str]
    name: Optional[str]


@dataclass
class Verified:
    """The verified state of the licence on this device (09 section 1.1), the fields of the Node SDK in snake_case."""

    valid: bool
    reason: Optional[str]
    state: Optional[str]
    read_only: bool
    licence: Optional[str]
    revision: Optional[int]
    product: Optional[str]
    environment: Optional[str]
    customer: Optional[Customer]
    edition: Optional[Edition]
    model: Optional[str]
    entitlements: Optional[Dict[str, Union[bool, int]]]
    starts: Optional[str]
    expires: Optional[str]
    grace_until: Optional[str]
    maintenance_until: Optional[str]
    slot: Optional[int]
    limit: Optional[int]
    lease_until: Optional[str]
    device_match: Optional[int]
    check_in_due: bool

    def has(self, key: str) -> bool:
        """True when the entitlement is on: true, or a number above zero."""
        value = (self.entitlements or {}).get(key)
        return value is True or (is_js_number(value) and value > 0)

    def get(self, key: str) -> Optional[Union[bool, int]]:
        """The entitlement's value, or None when the licence does not have it."""
        return (self.entitlements or {}).get(key)

    def within(self, key: str, count: Union[int, float]) -> bool:
        """True when count is within the licence's limit for key, for example within("employees", 120).

        A licence without that key has no limit, so any count is within it; an invalid licence is never within. On or
        off keys answer their value.
        """
        if not self.valid:
            return False
        value = (self.entitlements or {}).get(key)
        if value is None:
            return True
        if isinstance(value, bool):
            return value
        return count <= value

    def covers_build(self, build_date: Union[datetime, date]) -> bool:
        """Maintenance licences: true when a build of that date is inside maintenance. Other models: always true."""
        if self.model != "maintenance":
            return True
        until = parse_time(self.maintenance_until)
        if isinstance(build_date, datetime):
            at = _ms(build_date)
        else:
            at = calendar.timegm(build_date.timetuple()) * 1000
        return at <= until


@dataclass
class CheckInResult:
    """status is not_activated, not_due, skipped_offline, updated or unchanged; result is set for the last two."""

    status: str
    result: Optional[Verified] = None


def _sub(payload: Optional[Dict[str, Any]], name: str) -> Any:
    return None if payload is None else payload.get(name)


def _to_verified(core: Dict[str, Any], token: Optional[str], activation_token: Optional[str], at: datetime, hours: Optional[float]) -> Verified:
    payload = _payload_of(token) if core.get("valid") else None
    activation = _payload_of(activation_token) if core.get("valid") else None
    customer = _sub(payload, "customer")
    edition = _sub(payload, "edition")
    issued_at = _sub(activation, "issuedAt")
    issued = parse_time(issued_at) if isinstance(issued_at, str) else None
    due = issued is not None and hours is not None and issued + hours * HOUR_MS < _ms(at)
    revision = core.get("revision")
    if isinstance(revision, float) and revision != revision:
        revision = None
    return Verified(
        valid=core.get("valid") is True,
        reason=core.get("reason"),
        state=core.get("state"),
        read_only=core.get("readOnly") is True,
        licence=_sub(payload, "licence"),
        revision=revision,
        product=_sub(payload, "product"),
        environment=_sub(payload, "environment"),
        customer=Customer(customer.get("id"), customer.get("name")) if isinstance(customer, dict) else None,
        edition=Edition(edition.get("code"), edition.get("name")) if isinstance(edition, dict) else None,
        model=_sub(payload, "model"),
        entitlements=core.get("entitlements"),
        starts=_sub(payload, "starts"),
        expires=_sub(payload, "expires"),
        grace_until=_sub(payload, "graceUntil"),
        maintenance_until=core.get("maintenanceUntil"),
        slot=core.get("slot"),
        limit=core.get("limit"),
        lease_until=core.get("leaseUntil"),
        device_match=core.get("deviceMatch"),
        check_in_due=bool(due),
    )


# --------------------------------------------------------------------------------------------------------------- client


class Veryion:
    """The licensing client for one product.

    keys: the key set token (vyk1) from the Developer page, or a dict of kid to base64url public key.
    allow_sandbox: accept Sandbox licences (testing only; a shipped app must refuse them).
    storage: FileStorage() for the operating system's folder, MemoryStorage(), or any object with read() and write(text).
    http: a transport (tests); default urllib. clock: a function returning the current datetime (tests).
    auto_check_in: check in on a background daemon timer when due. Off by default: call check_in() yourself.
    """

    def __init__(
        self,
        product: str,
        keys: Union[str, Mapping[str, str]],
        allow_sandbox: bool = False,
        storage: Optional[Union[Storage, FileStorage]] = None,
        api_base_url: str = "https://api.veryion.com",
        send_hostname: bool = True,
        app_version: Optional[str] = None,
        timeout: float = 10,
        clock: Optional[Callable[[], datetime]] = None,
        http: Optional[Transport] = None,
        auto_check_in: bool = False,
    ) -> None:
        if not isinstance(product, str) or not _PRODUCT.fullmatch(product):
            raise VeryionError("invalid_config", "product must be a product code such as RGN.")
        self.product = product
        self.allow_sandbox = bool(allow_sandbox)
        self.api_base_url = api_base_url
        self.send_hostname = send_hostname
        self.app_version = app_version
        self.timeout = timeout
        self.auto_check_in = auto_check_in
        self._clock: Callable[[], datetime] = clock or (lambda: datetime.now(timezone.utc))
        self._http: Transport = http or urllib_transport
        self._trusted, self._vendor = _vendor_of(keys, product)
        self._storage: Storage = storage.bind(product, self._vendor) if isinstance(storage, FileStorage) else (storage if storage is not None else MemoryStorage())
        self._state: Dict[str, Any] = self._empty_state()
        self._collected: Optional[Fingerprint] = None
        self._initialised = False
        self._lock = threading.RLock()
        self._listeners: Dict[str, List[Callable[[Any], None]]] = {}
        self._last_result: Optional[Verified] = None
        self._release_secret: Optional[bytes] = None
        self._timer: Optional[threading.Timer] = None
        self._offline_retries = 0

    # ---------------------------------------------------------------------------------------------------------- state

    def _empty_state(self) -> Dict[str, Any]:
        return {
            "format": 1,
            "product": self.product,
            "keys": dict(self._trusted),
            "licenceToken": None,
            "activationToken": None,
            "highestRevision": {},
            "latestActivationIssuedAt": {},
            "lastTrustedTime": None,
            "lastCheckInAt": None,
            "nextCheckInAt": None,
        }

    def on(self, event: str, listener: Callable[[Any], None]) -> "Veryion":
        """Listen for "change" (a Verified whose validity, state, revision, read only or entitlements changed) or "error"
        (a VeryionError from storage or an automatic check in)."""
        self._listeners.setdefault(event, []).append(listener)
        return self

    def _emit(self, event: str, value: Any) -> None:
        for listener in list(self._listeners.get(event, [])):
            listener(value)

    def init(self) -> None:
        """Reads storage and collects the fingerprint. Safe to call twice; must finish before verify."""
        with self._lock:
            if self._initialised:
                return
            self._load()
            self._initialised = True

    def _load(self) -> None:
        result: Dict[str, Any] = {}

        def read() -> None:
            try:
                result["text"] = self._storage.read()
            except Exception as error:  # noqa: BLE001
                result["error"] = error

        reader = threading.Thread(target=read, daemon=True)
        reader.start()
        self._collected = collect_fingerprint(self.product, self.allow_sandbox)
        reader.join()
        if "error" in result:
            self._emit("error", VeryionError("storage_error", f"Storage could not be read: {result['error']}"))
        text = result.get("text")
        if self.allow_sandbox and os.environ.get("VY_TEST_DEVICE"):
            self._emit("error", VeryionError("invalid_config", "Test device hooks are active."))
        if text:
            try:
                parsed = json.loads(text)
            except ValueError:
                quarantine = getattr(self._storage, "quarantine", None)
                if callable(quarantine):
                    try:
                        quarantine()
                    except Exception:  # noqa: BLE001
                        pass
                self._emit("error", VeryionError("storage_error", "The stored state was corrupt and has been set aside. Activate the licence again."))
            else:
                if isinstance(parsed, dict) and parsed.get("format") == 1 and parsed.get("format") is not True and parsed.get("product") == self.product:
                    state = self._empty_state()
                    state.update(parsed)
                    stored_keys = parsed.get("keys") if isinstance(parsed.get("keys"), dict) else {}
                    state["keys"] = {**self._trusted, **stored_keys}
                    for name in ("highestRevision", "latestActivationIssuedAt"):
                        if not isinstance(state.get(name), dict):
                            state[name] = {}
                    self._state = state
        self._schedule_check_in()

    def _persist(self) -> None:
        try:
            self._storage.write(json.dumps(self._state, indent=2, ensure_ascii=False))
        except Exception as error:  # noqa: BLE001
            self._emit("error", VeryionError("storage_error", f"Storage could not be written: {error}"))

    def _ready(self) -> None:
        self.init()

    # --------------------------------------------------------------------------------------------------------- verify

    def verify(self, token: Optional[str] = None, activation_token: Optional[str] = None, now: Optional[datetime] = None) -> Verified:
        """The verified state, from memory only (section 1). Raises not_initialised before init()."""
        with self._lock:
            if self._collected is None:
                raise VeryionError("not_initialised", "Call init() before verify().")
            at = now or self._clock()
            use_token = token if token is not None else self._state.get("licenceToken")
            use_activation = activation_token if activation_token is not None else self._state.get("activationToken")
            # No licence token (never activated, or the state file is gone after a restart): activation_required.
            if use_token:
                core = verify_licence(
                    use_token,
                    product=self.product,
                    allow_sandbox=self.allow_sandbox,
                    trusted_keys=self._trusted,
                    now=_iso(at),
                    activation_token=use_activation,
                    stored={
                        "highestRevision": self._state["highestRevision"],
                        "latestActivationIssuedAt": self._state["latestActivationIssuedAt"],
                        "lastTrustedTime": self._state.get("lastTrustedTime"),
                    },
                    device=self._collected.components,
                )
            else:
                core = {"valid": False, "reason": "activation_required"}
            result = _to_verified(core, use_token, use_activation, at, _check_in_hours(use_token))
            if result.valid and token is None:
                licence = result.licence
                highest = self._state["highestRevision"]
                before = (highest.get(licence or ""), self._state.get("lastTrustedTime"))
                if licence and result.revision is not None:
                    highest[licence] = max(highest.get(licence, 0), result.revision)
                self._state["lastTrustedTime"] = _iso(at)
                # Only a change is written: a verify that learns nothing new does no I/O.
                if before != (highest.get(licence or ""), self._state.get("lastTrustedTime")):
                    self._persist()
            self._emit_if_changed(result)
            return result

    def _emit_if_changed(self, result: Verified) -> None:
        def key(item: Verified) -> str:
            return json.dumps([item.valid, item.state, item.revision, item.read_only, item.entitlements])

        previous = key(self._last_result) if self._last_result is not None else None
        self._last_result = result
        if previous is not None and previous != key(result):
            self._emit("change", result)

    def status(self) -> Dict[str, Any]:
        licence = _payload_of(self._state.get("licenceToken"))
        activation = _payload_of(self._state.get("activationToken"))
        return {
            "activated": self._state.get("activationToken") is not None,
            "licence": licence.get("licence") if licence else None,
            "activation": activation.get("activation") if activation else None,
            "revision": self._state["highestRevision"].get(licence.get("licence") or "") if licence else None,
            "last_check_in_at": self._state.get("lastCheckInAt"),
            "next_check_in_at": self._state.get("nextCheckInAt"),
            "trusted_kids": list(self._trusted),
            "storage_path": getattr(self._storage, "path", None),
        }

    def _set_device_for_tests(self, components: Mapping[str, str]) -> None:
        """Test seam (section 8, step 3): sets the device's component hashes. Not part of the public API."""
        self._collected = Fingerprint(components=dict(components), missing=[name for name in COMPONENTS if name not in components])
        self._initialised = True

    def fingerprint(self) -> Fingerprint:
        """The six component hashes of this device and the names it could not read (section 1)."""
        self._ready()
        return self._collected or Fingerprint(components={}, missing=list(COMPONENTS))

    # ------------------------------------------------------------------------------------------------ online actions

    def activate(self, licence_key: str, user: Optional[str] = None) -> Verified:
        """Activates this device (online, once per device). user: a named user ID, sent only as a hash."""
        self._ready()
        with self._lock:
            key_fields = activate_key_fields(licence_key)
            if "licenceKey" in key_fields and not is_valid_licence_key(key_fields["licenceKey"]):
                raise VeryionError("invalid_licence_key", "That licence key has a typo. Check it and try again.")
            fp = self._collected
            assert fp is not None
            if len(fp.components) < 2:
                raise VeryionError("device_unidentifiable", "This device could not be identified.")
            at = self._clock()
            body = {
                **key_fields,
                "product": self.product,
                "components": fp.components,
                "user": user_hash(self.product, user) if user else None,
                "hostname": socket.gethostname() if self.send_hostname else None,
                "osName": sys.platform,
                "appVersion": self.app_version,
                "sdk": SDK_NAME,
                "clientTime": _iso(at),
                "trustedKids": list(self._trusted),
                "testDevice": True if self.allow_sandbox and os.environ.get("VY_TEST_DEVICE") else None,
            }
        # The network call runs outside the lock, so verify() on other threads never waits for the server.
        response = self._post("/v1/licence/activate", body)
        with self._lock:
            key_set = response.get("keySet")
            if isinstance(key_set, str) and key_set:
                self._trusted = apply_key_set(key_set, self.product, self._trusted)
            if response.get("licence"):
                self._accept_licence(response["licence"])
            activation = response.get("activation")
            if activation:
                self._accept_activation(activation.get("token") if isinstance(activation, dict) else None)
            self._state["lastCheckInAt"] = _iso(at)
            self._state["keys"] = dict(self._trusted)
            self._persist()
            result = self.verify()
            self._offline_retries = 0
            self._schedule_check_in()
            return result

    def _accept_licence(self, token: Any) -> None:
        checked = parse_token(token, "vy1", self._trusted) if isinstance(token, str) else None
        if checked is None or checked.error or checked.payload is None:
            raise VeryionError("server_response_invalid", "The licence from the server failed verification.")
        self._state["licenceToken"] = token
        licence = checked.payload.get("licence")
        revision = checked.payload.get("revision")
        if licence and is_js_number(revision):
            highest = self._state["highestRevision"]
            highest[licence] = max(highest.get(licence, 0), revision)

    def _accept_activation(self, token: Any) -> None:
        checked = parse_token(token, "vya1", self._trusted) if isinstance(token, str) else None
        if checked is None or checked.error or checked.payload is None:
            raise VeryionError("server_response_invalid", "The activation from the server failed verification.")
        self._state["activationToken"] = token
        licence = checked.payload.get("licence")
        issued_at = checked.payload.get("issuedAt")
        if licence and issued_at:
            self._state["latestActivationIssuedAt"][licence] = issued_at

    def check_in(self, force: bool = False) -> CheckInResult:
        """Checks in when due (or when forced). Offline is a status, never an exception (section 3)."""
        self._ready()
        with self._lock:
            token = self._state.get("activationToken")
            if not token:
                return CheckInResult("not_activated")
            now = self._clock()
            before = self.verify(now=now)
            if not force and not before.check_in_due:
                return CheckInResult("not_due")
            licence = _payload_of(self._state.get("licenceToken"))
            licence_id = licence.get("licence") if licence else None
            revision = (licence_id and self._state["highestRevision"].get(licence_id)) or 0
            assert self._collected is not None
            body = {
                "activationToken": token,
                "licenceRevision": revision,
                "components": self._collected.components,
                "appVersion": self.app_version,
                "sdk": SDK_NAME,
                "clientTime": _iso(now),
                "trustedKids": list(self._trusted),
            }
        try:
            response = self._post("/v1/licence/check-in", body)
        except VeryionError as error:
            if error.code in ("network_error", "timeout"):
                return CheckInResult("skipped_offline")
            if error.code == "device_mismatch":
                with self._lock:
                    self._state["activationToken"] = None
                    self._persist()
            raise
        with self._lock:
            if response.get("licence"):
                self._accept_licence(response["licence"])
            activation = response.get("activation")
            if activation:
                self._accept_activation(activation.get("token") if isinstance(activation, dict) else None)
            self._state["lastCheckInAt"] = _iso(now)
            hours = (licence or {}).get("checkInHours")
            hours = hours if is_js_number(hours) else 24
            self._state["nextCheckInAt"] = _iso(_from_ms(_ms(now) + hours * HOUR_MS))
            self._persist()
            after = self.verify(now=now)
            changed = before.valid != after.valid or before.revision != after.revision or before.state != after.state or before.read_only != after.read_only
            self._offline_retries = 0
            self._schedule_check_in()
            return CheckInResult("updated" if changed else "unchanged", after)

    def deactivate(self) -> None:
        """Frees this device's slot. Offline: raises network_error and keeps everything."""
        self._ready()
        with self._lock:
            token = self._state.get("activationToken")
            if not token:
                return
        self._post("/v1/licence/deactivate", {"activationToken": token})
        with self._lock:
            self._state["activationToken"] = None
            self._state["licenceToken"] = None
            self._state["latestActivationIssuedAt"] = {}
            self._persist()
            self._cancel_timer()

    def load_licence_file(self, text: str) -> Verified:
        """A licence file (for licences that need no activation): the vy1 token text."""
        self._ready()
        with self._lock:
            self._state["licenceToken"] = js_trim(text)
            self._persist()
            return self.verify()

    # -------------------------------------------------------------------------------------------------------- offline

    def offline_request(self, licence_key: str) -> OfflineRequest:
        """The request file for an air gapped device (Phase 10 06 section 7.1). Keep this client running until the
        response is loaded. The release secret is kept with the state, so the device can give its seat back after a
        restart (06 sections 6.5 and 6.6)."""
        self._ready()
        with self._lock:
            stored = self._state.get("offlineReleaseSecret")
            if self._release_secret is None and isinstance(stored, str) and stored:
                self._release_secret = decode_base64url_strict(stored)
            if self._release_secret is None:
                self._release_secret = new_release_secret()
                self._state["offlineReleaseSecret"] = base64.urlsafe_b64encode(self._release_secret).decode("ascii").rstrip("=")
                self._persist()
            fields = activate_key_fields(licence_key)
            components = dict(self._collected.components) if self._collected is not None else {"cpu": "00", "disk": "00"}
            return build_offline_request(
                product=self.product,
                licence_key=fields.get("licenceKey"),
                legacy_key=fields.get("legacyKey"),
                components=components,
                app_version=self.app_version,
                sdk=SDK_NAME,
                created_at=_iso(self._clock()),
                release_secret=self._release_secret,
            )

    def load_offline_response(self, text: str) -> Verified:
        """Loads the response file from the console (licence, activation and key set lines) and verifies it."""
        with self._lock:
            parts = split_offline_response(text)
            # Line 3, the key set: an offline device learns new signing keys only here (06 section 6.4).
            if parts.key_set:
                self._trusted = apply_key_set(parts.key_set, self.product, self._trusted)
                self._state["keys"] = dict(self._trusted)
            self._state["licenceToken"] = parts.licence
            self._state["activationToken"] = parts.activation
            self._persist()
            return self.verify()

    def offline_release(self) -> OfflineRelease:
        """The release file that frees an offline activation. Forgets the tokens on this device."""
        with self._lock:
            stored = self._state.get("offlineReleaseSecret")
            if self._release_secret is None and isinstance(stored, str) and stored:
                self._release_secret = decode_base64url_strict(stored)
            if self._release_secret is None:
                raise VeryionError("invalid_config", "No offline release secret is stored.")
            # The release names the activation and licence by their public IDs, read from the activation token (6.5).
            token = _payload_of(self._state.get("activationToken")) or {}
            activation = token.get("activation") if isinstance(token.get("activation"), str) else "ACT-UNKNOWN"
            licence = token.get("licence") if isinstance(token.get("licence"), str) else ((self._last_result.licence if self._last_result else None) or "LIC-UNKNOWN")
            # The device stops working before the file exists: tokens and secret go first.
            self._state["licenceToken"] = None
            self._state["activationToken"] = None
            self._state["offlineReleaseSecret"] = None
            out = build_offline_release(
                activation=activation,
                licence=licence,
                product=self.product,
                release_secret=self._release_secret,
                released_at=_iso(self._clock()),
            )
            self._release_secret = None
            self._persist()
            return out

    # ------------------------------------------------------------------------------------------------ automatic check in

    def close(self) -> None:
        """Stops the automatic check in timer."""
        self._cancel_timer()

    def _cancel_timer(self) -> None:
        if self._timer is not None:
            self._timer.cancel()
        self._timer = None

    def _schedule_check_in(self, delay_ms: Optional[float] = None) -> None:
        self._cancel_timer()
        if not self.auto_check_in or not self._state.get("activationToken") or self._collected is None:
            return
        if delay_ms is None:
            now = _ms(self._clock())
            hours = _check_in_hours(self._state.get("licenceToken"))
            hours = 24 if hours is None else hours
            issued = parse_time((_payload_of(self._state.get("activationToken")) or {}).get("issuedAt"))
            issued = now if issued != issued else issued
            due = issued + hours * HOUR_MS
            jitter = random.random() * 0.1 * hours * HOUR_MS
            delay_ms = max(CHECK_IN_FIRST_MS, due - now + jitter)
        timer = threading.Timer(min(delay_ms, 2_147_483_647) / 1000.0, self._automatic_check_in)
        timer.daemon = True
        self._timer = timer
        timer.start()

    def _automatic_check_in(self) -> None:
        try:
            result = self.check_in()
        except Exception as error:  # noqa: BLE001
            self._emit("error", error)
            return
        if result.status == "skipped_offline":
            delay = OFFLINE_RETRY_MS[min(self._offline_retries, len(OFFLINE_RETRY_MS) - 1)]
            self._offline_retries += 1
            self._schedule_check_in(delay)
        elif result.status == "not_due":
            self._schedule_check_in()

    # ----------------------------------------------------------------------------------------------------------- HTTP

    def _post(self, path: str, body: Mapping[str, Any]) -> Dict[str, Any]:
        url = self.api_base_url.rstrip("/") + path
        # JSON.stringify drops undefined fields: unset fields are left out.
        data = json.dumps({key: value for key, value in body.items() if value is not None}, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        headers = {"content-type": "application/json", "accept": "application/json"}
        try:
            response = self._http(url, data, headers, float(self.timeout))
        except (TimeoutError, socket.timeout) as error:
            raise VeryionError("timeout", "The server did not answer in time.") from error
        except Exception as error:  # noqa: BLE001
            raise VeryionError("network_error", "The server could not be reached.") from error
        try:
            answer = json.loads(response.text) if response.text else {}
        except ValueError as error:
            raise VeryionError("server_response_invalid", f"The server answered {response.status} with a body that is not JSON.", status=response.status) from error
        if not isinstance(answer, dict):
            answer = {}
        if 200 <= response.status < 300:
            return answer
        server_error = answer.get("error") if isinstance(answer.get("error"), dict) else {}
        details = server_error.get("details") if isinstance(server_error.get("details"), dict) else {}
        retry = js_number(response.header("retry-after") or "0")
        message = server_error.get("message")
        raise VeryionError(
            map_code(response.status, server_error.get("code")),
            message if isinstance(message, str) else f"The server answered {response.status}.",
            status=response.status,
            request_id=server_error.get("requestId"),
            state=details.get("state") if isinstance(details.get("state"), str) else None,
            limit=details.get("limit") if is_js_number(details.get("limit")) else None,
            active=details.get("active") if is_js_number(details.get("active")) else None,
            retry_after_seconds=retry if retry and retry == retry else None,
        )


__all__ = [
    "CheckInResult",
    "Customer",
    "Edition",
    "HttpResponse",
    "SDK_VERSION",
    "Transport",
    "Verified",
    "Veryion",
    "map_code",
    "urllib_transport",
]
