"""Small helpers that give JavaScript's answers, so the Python verifier decides exactly like the Node SDK.

The payloads only ever hold str, bool, int and dict (the strict parser refuses everything else), but a few steps of
05 section 7 convert values (String(), Number(), strict equality) and these follow the JavaScript rules for those types.
"""
from __future__ import annotations

import math
import re
from typing import Any

NAN = float("nan")

# The characters JavaScript's String.prototype.trim and the \s class treat as white space.
JS_WHITESPACE = "\t\n\v\f\r                  　﻿"
JS_WS_RUN = re.compile("[" + re.escape(JS_WHITESPACE) + "]+")


def js_trim(text: str) -> str:
    return text.strip(JS_WHITESPACE)


def js_string(value: Any) -> str:
    """String(value) for the JSON value types."""
    if value is None:
        return "undefined"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return value
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN"
        if value.is_integer():
            return str(int(value))
        return repr(value)
    if isinstance(value, dict):
        return "[object Object]"
    return str(value)


_DECIMAL = re.compile(r"^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$")


def js_number(value: Any) -> float | int:
    """Number(value) for the JSON value types. NaN is float('nan'), which compares like JavaScript's NaN."""
    if value is None:
        return NAN
    if value is True:
        return 1
    if value is False:
        return 0
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return value
    if isinstance(value, str):
        text = js_trim(value)
        if text == "":
            return 0
        if _DECIMAL.match(text):
            number = float(text)
            return int(number) if number.is_integer() and abs(number) < 2**63 else number
        lowered = text.lower()
        for prefix, base in (("0x", 16), ("0o", 8), ("0b", 2)):
            if lowered.startswith(prefix):
                try:
                    return int(text[2:], base)
                except ValueError:
                    return NAN
        if text in ("Infinity", "+Infinity"):
            return math.inf
        if text == "-Infinity":
            return -math.inf
        return NAN
    return NAN


def js_strict_equal(a: Any, b: Any) -> bool:
    """a === b. Objects are equal only when they are the same object; true is never 1."""
    if a is None or b is None:
        return a is b
    if isinstance(a, dict) or isinstance(b, dict):
        return a is b
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a == b
    return type(a) is type(b) and a == b


def is_js_number(value: Any) -> bool:
    """typeof value === 'number'."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _days_from_civil(year: int, month: int, day: int) -> int:
    year -= month <= 2
    era = (year if year >= 0 else year - 399) // 400
    yoe = year - era * 400
    doy = (153 * (month + (-3 if month > 2 else 9)) + 2) // 5 + day - 1
    doe = yoe * 365 + yoe // 4 - yoe // 100 + doy
    return era * 146097 + doe - 719468


_TIME = re.compile(r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})Z$")


def parse_time(value: Any) -> float:
    """Date.parse for the time format of 05 section 3, in milliseconds since the epoch; NaN when it does not parse.

    Like V8: day 1 to 31 in any month (a day past the month's end rolls over), hour 24 only as 24:00:00.
    """
    if not isinstance(value, str):
        return NAN
    match = _TIME.match(value)
    if not match:
        return NAN
    year, month, day, hour, minute, second = (int(part) for part in match.groups())
    if not (1 <= month <= 12 and 1 <= day <= 31 and minute <= 59 and second <= 59):
        return NAN
    if hour > 24 or (hour == 24 and (minute or second)):
        return NAN
    days = _days_from_civil(year, month, 1) + day - 1
    return float(((days * 24 + hour) * 60 + minute) * 60 + second) * 1000.0
