"""Phase 10 06 section 4.2: named user hashing on the device. Clear user IDs never leave the device. A port of
sdks/node/src/named.ts."""
from __future__ import annotations

import hashlib
import unicodedata

from .core.jsvalues import js_trim


def normalise_user_id(raw: str) -> str:
    return js_trim(unicodedata.normalize("NFC", raw)).lower()


def user_hash(product_code: str, raw_user_id: str) -> str:
    normalised = normalise_user_id(raw_user_id)
    return hashlib.sha256(f"vyu1:{product_code}:{normalised}".encode("utf-8")).hexdigest()
