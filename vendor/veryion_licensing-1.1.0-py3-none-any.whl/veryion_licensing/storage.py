"""Storage (09-sdks.md section 4). One JSON file per product and vendor, written atomically.

Custom storage implements read() and write(text); the file holds only signed tokens and harmless numbers. A port of
sdks/node/src/storage.ts: the same folders, the same file names and the same JSON state.
"""
from __future__ import annotations

import getpass
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import List, Mapping, Optional

try:  # Python 3.8+: typing.Protocol
    from typing import Protocol, runtime_checkable
except ImportError:  # pragma: no cover
    Protocol = object  # type: ignore

    def runtime_checkable(cls):  # type: ignore
        return cls


@runtime_checkable
class Storage(Protocol):
    """What the client needs from a store: the state text back, or None when there is none yet."""

    def read(self) -> Optional[str]: ...

    def write(self, text: str) -> None: ...


class MemoryStorage:
    """Keeps the state in memory (tests, and vendors who persist elsewhere through their own storage)."""

    path: Optional[str] = None

    def __init__(self, text: Optional[str] = None) -> None:
        self.text = text

    def read(self) -> Optional[str]:
        return self.text

    def write(self, text: str) -> None:
        self.text = text


_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def restrict_to_current_user(path: str, folder: bool = False) -> None:
    """Windows has no 0600: the folder and file keep only the current user's access (section 4).

    Inherited access is removed and the current user gets full control. Best effort, like the Node SDK: a failure leaves
    the profile's own access list in place. A folder's grant is inheritable, so files created in it inherit the current
    user's entry alone; a file takes a plain grant.
    """
    if sys.platform != "win32":
        return
    try:
        user = getpass.getuser()
    except Exception:
        return
    icacls = os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "System32", "icacls.exe")
    grant = f"{user}:(OI)(CI)(F)" if folder else f"{user}:(F)"
    try:
        subprocess.run(
            [icacls, path, "/inheritance:r", "/grant:r", grant],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            timeout=10,
            creationflags=_NO_WINDOW,
        )
    except Exception:
        pass


def default_folder(product: str, vendor: str, platform: Optional[str] = None, env: Optional[Mapping[str, str]] = None) -> str:
    """The default folder of a product and vendor on each system (section 4)."""
    platform = platform or sys.platform
    env = os.environ if env is None else env
    name = f"{product}_{vendor}"
    home = str(Path.home())
    if platform == "win32":
        return os.path.join(env.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local"), "Veryion", name)
    if platform == "darwin":
        return os.path.join(home, "Library", "Application Support", "Veryion", name)
    return os.path.join(env.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share"), "veryion", name)


class BoundFileStorage:
    """The state file of one product and vendor: {folder}/state.json."""

    def __init__(self, folder: str) -> None:
        self.folder = folder
        self.path = os.path.join(folder, "state.json")
        self._lock = threading.Lock()
        self._folder_restricted = False

    def read(self) -> Optional[str]:
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                return handle.read()
        except FileNotFoundError:
            return None

    def write(self, text: str) -> None:
        """Writes state.json.tmp, flushes, and renames it over state.json. Folder 0700, file 0600 on POSIX (section 4).

        Writes run one at a time: they share the temporary file name.
        """
        with self._lock:
            os.makedirs(self.folder, mode=0o700, exist_ok=True)
            if not self._folder_restricted:
                if sys.platform != "win32":
                    try:
                        os.chmod(self.folder, 0o700)
                    except OSError:
                        pass
                restrict_to_current_user(self.folder, True)
                self._folder_restricted = True
            temp = f"{self.path}.tmp"
            try:
                flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_BINARY", 0)
                descriptor = os.open(temp, flags, 0o600)
                with os.fdopen(descriptor, "wb") as handle:
                    handle.write(text.encode("utf-8"))
                    handle.flush()
                    os.fsync(handle.fileno())
                try:
                    os.chmod(temp, 0o600)
                except OSError:
                    pass
                restrict_to_current_user(temp)
                os.replace(temp, self.path)
            except FileNotFoundError:
                # The folder can disappear mid write (a test wiping state, or the host clearing product data).
                return

    def quarantine(self) -> str:
        """A corrupt file is moved aside and the state starts empty (section 4)."""
        target = f"{self.path}.corrupt-{int(time.time())}"
        os.replace(self.path, target)
        return target

    def remove(self) -> None:
        try:
            os.unlink(self.path)
        except OSError:
            pass

    def idle(self) -> None:
        """Writes are synchronous in Python; kept for parity with the Node SDK."""
        with self._lock:
            return None


class FileStorage:
    """The file storage. Bound to a product and vendor by the client (bind), which chooses the folder."""

    def __init__(self, folder: Optional[str] = None) -> None:
        self.folder = None if folder is None else os.fspath(folder)
        self._bound: List[BoundFileStorage] = []

    def bind(self, product: str, vendor: str) -> BoundFileStorage:
        """Used by the client: the folder for this product and vendor unless one was given."""
        storage = BoundFileStorage(self.folder if self.folder is not None else default_folder(product, vendor))
        self._bound.append(storage)
        return storage

    def idle(self) -> None:
        for storage in self._bound:
            storage.idle()
