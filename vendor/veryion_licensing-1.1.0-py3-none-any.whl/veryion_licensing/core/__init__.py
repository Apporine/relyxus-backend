"""The licence core: strict canonical JSON, base64url, schemas, Ed25519 verification, key sets, fingerprint score and
licence key checks (05 licence format). No I/O happens here."""
from .base64url import decode_base64url_strict, encode_base64url
from .canonical import CanonicalError, MAX_PAYLOAD_BYTES, MAX_SAFE_INTEGER, Parsed, canonical_from_text, canonicalize, parse_strict
from .fingerprint import WEIGHTS, component_hash, normalise_component, score
from .licence_key import ALPHABET, check_character, format_licence_key, generate_licence_key, is_valid_licence_key
from .schemas import SchemaError, check_payload
from .verify import REASONS, ParseOutcome, apply_key_set, parse_token, verify_licence

__all__ = [
    "ALPHABET",
    "CanonicalError",
    "MAX_PAYLOAD_BYTES",
    "MAX_SAFE_INTEGER",
    "ParseOutcome",
    "Parsed",
    "REASONS",
    "SchemaError",
    "WEIGHTS",
    "apply_key_set",
    "canonical_from_text",
    "canonicalize",
    "check_character",
    "check_payload",
    "component_hash",
    "decode_base64url_strict",
    "encode_base64url",
    "format_licence_key",
    "generate_licence_key",
    "is_valid_licence_key",
    "normalise_component",
    "parse_strict",
    "parse_token",
    "score",
    "verify_licence",
]
