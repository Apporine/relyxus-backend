"""Veryion licensing for Python: offline licence verification, activation, check in and deactivation.

A port of the Node SDK (@veryion/licensing 1.1.0) with the same guarantees: licences are verified on the device with
Ed25519 and never need the network to answer verify().
"""
from .client import SDK_VERSION, CheckInResult, Customer, Edition, HttpResponse, Transport, Verified, Veryion, map_code, urllib_transport
from .errors import ERROR_CODES, VeryionError
from .fingerprint import COMPONENTS, Fingerprint, collect_fingerprint
from .legacy import activate_key_fields, looks_like_licence_key
from .named import normalise_user_id, user_hash
from .offline import (
    OfflineRelease,
    OfflineRequest,
    OfflineResponse,
    build_offline_release,
    build_offline_request,
    new_release_secret,
    release_commit_of,
    split_offline_response,
)
from .storage import BoundFileStorage, FileStorage, MemoryStorage, Storage, default_folder

__version__ = SDK_VERSION

__all__ = [
    "BoundFileStorage",
    "COMPONENTS",
    "CheckInResult",
    "Customer",
    "ERROR_CODES",
    "Edition",
    "FileStorage",
    "Fingerprint",
    "HttpResponse",
    "MemoryStorage",
    "OfflineRelease",
    "OfflineRequest",
    "OfflineResponse",
    "SDK_VERSION",
    "Storage",
    "Transport",
    "Verified",
    "Veryion",
    "VeryionError",
    "activate_key_fields",
    "build_offline_release",
    "build_offline_request",
    "collect_fingerprint",
    "default_folder",
    "looks_like_licence_key",
    "map_code",
    "new_release_secret",
    "normalise_user_id",
    "release_commit_of",
    "split_offline_response",
    "urllib_transport",
    "user_hash",
    "__version__",
]
