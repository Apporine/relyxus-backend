"""05 licence format sections 3 to 5: the required fields and the rules a payload must meet before its signature is
checked. A port of sdks/node/src/core/schemas.ts (which mirrors tools/vectors/reference_verify.py)."""
from __future__ import annotations

import re
import unicodedata
from typing import Any, Dict, Tuple

from .canonical import MAX_SAFE_INTEGER

REQUIRED: Dict[str, Tuple[str, ...]] = {
    "vy1": ("customer", "edition", "entitlements", "environment", "issuedAt", "kid", "licence", "model", "organisation", "product", "revision", "starts"),
    "vya1": ("activation", "components", "environment", "issuedAt", "kid", "licence", "product", "revision", "state"),
    "vyk1": ("environment", "issuedAt", "keys", "kid", "organisation", "product"),
}

TIME_FIELDS = ("issuedAt", "starts", "expires", "graceUntil", "maintenanceUntil", "leaseUntil")
_TIME = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", re.ASCII)


class SchemaError(ValueError):
    pass


def _check_value(value: Any) -> None:
    if isinstance(value, bool):
        return
    if isinstance(value, int):
        if abs(value) > MAX_SAFE_INTEGER:
            raise SchemaError("integer")
        return
    if isinstance(value, str):
        if unicodedata.normalize("NFC", value) != value:
            raise SchemaError("nfc")
        return
    if isinstance(value, dict):
        for key, inner in value.items():
            if not all(ord(ch) < 0x80 for ch in key):
                raise SchemaError("key")
            _check_value(inner)
        return
    raise SchemaError("type")


def check_payload(kind: str, payload: Dict[str, Any]) -> None:
    """Raises SchemaError when the payload breaks the rules for its kind."""
    for field in REQUIRED[kind]:
        if field not in payload:
            raise SchemaError(f"missing {field}")
    _check_value(payload)
    for field in TIME_FIELDS:
        if field in payload:
            value = payload[field]
            if not isinstance(value, str) or not _TIME.fullmatch(value):
                raise SchemaError(f"time {field}")
    if payload.get("environment") not in ("production", "sandbox") or not isinstance(payload.get("environment"), str):
        raise SchemaError("environment")
