"""RFC 4648 section 5, unpadded. Strict: the text must be exactly what encoding the bytes gives back."""
from __future__ import annotations

import base64
import binascii
import re
from typing import Optional

_ALPHABET = re.compile(r"[A-Za-z0-9_-]*")


def encode_base64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(bytes(data)).rstrip(b"=").decode("ascii")


def decode_base64url_strict(text: str) -> Optional[bytes]:
    """The decoded bytes, or None when the text is not canonical base64url."""
    if not isinstance(text, str) or not _ALPHABET.fullmatch(text) or len(text) % 4 == 1:
        return None
    try:
        data = base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))
    except (binascii.Error, ValueError):
        return None
    return data if encode_base64url(data) == text else None
