"""05 licence format section 8: device components, their hashes and the match score. A port of
sdks/node/src/core/fingerprint.ts."""
from __future__ import annotations

import hashlib
from typing import Any, Dict, Optional

from .jsvalues import JS_WS_RUN, js_strict_equal, js_trim

WEIGHTS: Dict[str, int] = {"board": 30, "cpu": 20, "disk": 18, "gpu": 14, "os": 10, "net": 8}

_PLACEHOLDERS = {"TO BE FILLED BY O.E.M.", "DEFAULT STRING", "NONE", "0", "00000000", "00:00:00:00:00:00"}


def normalise_component(raw: str) -> Optional[str]:
    """Trim, collapse inner whitespace, upper case. Empty and placeholder values mean "not reported"."""
    value = JS_WS_RUN.sub(" ", js_trim(raw)).upper()
    if value == "" or value in _PLACEHOLDERS:
        return None
    return value


def component_hash(product: str, component: str, raw: str) -> Optional[str]:
    """The 16 character hash that leaves the device: SHA-256 of "vyfp1:{product}:{component}:{value}"."""
    value = normalise_component(raw)
    if value is None:
        return None
    return hashlib.sha256(f"vyfp1:{product}:{component}:{value}".encode("utf-8")).hexdigest()[:16]


def score(stored: Any, current: Any) -> int:
    """The sum of weights of the stored components the current device has the same hash for, over the stored total."""
    if not isinstance(stored, dict):
        return 0
    current = current if isinstance(current, dict) else {}
    total = sum(WEIGHTS.get(component, 0) for component in stored)
    if total == 0:
        return 0
    hit = sum(
        WEIGHTS.get(component, 0)
        for component in stored
        if component in current and js_strict_equal(current[component], stored[component])
    )
    return (hit * 100) // total
