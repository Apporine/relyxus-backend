"""05 licence format section 7: the verification steps, in order. The first failing step decides the reason.

A port of sdks/node/src/core/verify.ts; tools/vectors/reference_verify.py follows the same steps and the shared vectors in
packages/licence-core/test-vectors prove all of them.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .base64url import decode_base64url_strict
from .canonical import CanonicalError, JsonObject, canonicalize, parse_strict
from .fingerprint import score
from .jsvalues import js_number, js_strict_equal, js_string, parse_time
from .schemas import SchemaError, check_payload

REASONS = (
    "malformed",
    "not_canonical",
    "unknown_key",
    "bad_signature",
    "wrong_product",
    "sandbox_not_allowed",
    "superseded",
    "clock_behind",
    "not_yet_valid",
    "expired",
    "activation_required",
    "activation_mismatch",
    "wrong_device",
    "suspended",
    "revoked",
    "deactivated",
    "lease_expired",
)

TrustedKeys = Dict[str, Optional[str]]

DAY_MS = 86_400_000


@dataclass
class ParseOutcome:
    payload: Optional[JsonObject] = None
    error: Optional[str] = None


# Public keys built once per key: building one costs more than the check itself.
_key_objects: Dict[bytes, Ed25519PublicKey] = {}


def _verify_signature(signature: bytes, body: bytes, key: bytes) -> bool:
    """Ed25519 verification of the 64 byte signature over the exact payload bytes (05 section 1). A malformed key is false."""
    try:
        public_key = _key_objects.get(key)
        if public_key is None:
            public_key = Ed25519PublicKey.from_public_bytes(key)
            _key_objects[key] = public_key
        public_key.verify(signature, body)
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def parse_token(token: str, kind: str, keys: Mapping[str, Optional[str]]) -> ParseOutcome:
    """Steps 1 to 5 for one token: shape, base64url, schema, canonical bytes, trusted key and signature."""
    if not isinstance(token, str):
        return ParseOutcome(error="malformed")
    parts = token.split(".")
    if len(parts) != 3 or parts[0] != kind:
        return ParseOutcome(error="malformed")
    body = decode_base64url_strict(parts[1])
    signature = decode_base64url_strict(parts[2])
    if not body or not signature or len(signature) != 64:
        return ParseOutcome(error="malformed")
    try:
        body_text = body.decode("utf-8", errors="strict")
        parsed = parse_strict(body_text)
        payload = parsed.value
        check_payload(kind, payload)
        # The signed bytes must be the canonical form exactly (05 section 2).
        if parsed.duplicate or canonicalize(payload) != body_text:
            return ParseOutcome(error="not_canonical")
    except CanonicalError as error:
        return ParseOutcome(error="not_canonical" if error.rule == "duplicate_key" else "malformed")
    except (SchemaError, UnicodeDecodeError, TypeError):
        return ParseOutcome(error="malformed")
    public_key = keys.get(js_string(payload.get("kid")))
    if public_key is None:
        return ParseOutcome(error="unknown_key")
    key = decode_base64url_strict(public_key)
    if not key:
        return ParseOutcome(error="unknown_key")
    if not _verify_signature(signature, body, key):
        return ParseOutcome(error="bad_signature")
    return ParseOutcome(payload=payload)


def apply_key_set(key_set: str, product: str, keys: Mapping[str, Optional[str]]) -> TrustedKeys:
    """Key set token (vyk1): accepted only when it verifies under a key already trusted for this product."""
    parsed = parse_token(key_set, "vyk1", keys)
    if parsed.error or parsed.payload is None:
        return dict(keys)
    payload = parsed.payload
    if not js_strict_equal(payload.get("product"), product):
        return dict(keys)
    entries = payload.get("keys")
    entries = entries if isinstance(entries, dict) else {}
    result: TrustedKeys = {}
    for kid, public_key in keys.items():
        entry = entries.get(kid)
        if not (isinstance(entry, dict) and "revokedAt" in entry):
            result[kid] = public_key
    for kid, entry in entries.items():
        if isinstance(entry, dict):
            if "revokedAt" not in entry:
                value = entry.get("publicKey")
                result[kid] = value if isinstance(value, str) else None
        else:
            result[kid] = None
    return result


def verify_licence(
    token: str,
    *,
    product: str,
    allow_sandbox: bool,
    trusted_keys: Mapping[str, Optional[str]],
    now: str,
    activation_token: Optional[str] = None,
    key_set: Optional[str] = None,
    stored: Optional[Mapping[str, Any]] = None,
    device: Optional[Mapping[str, str]] = None,
) -> Dict[str, Any]:
    """The licence verifier. The result carries only the fields 05 section 7 lists, with the camelCase names of the vectors.

    stored may hold highestRevision, latestActivationIssuedAt and lastTrustedTime (the names of the vectors).
    """
    keys = apply_key_set(key_set, product, trusted_keys) if key_set is not None else dict(trusted_keys)
    at = parse_time(now)
    stored = stored or {}
    highest = stored.get("highestRevision") or {}
    latest = stored.get("latestActivationIssuedAt") or {}
    last_trusted = stored.get("lastTrustedTime")

    licence = parse_token(token, "vy1", keys)
    if licence.error or licence.payload is None:
        return {"valid": False, "reason": licence.error}
    p = licence.payload
    if not js_strict_equal(p.get("product"), product):
        return {"valid": False, "reason": "wrong_product"}
    if js_strict_equal(p.get("environment"), "sandbox") and not allow_sandbox:
        return {"valid": False, "reason": "sandbox_not_allowed"}
    licence_id = js_string(p.get("licence"))
    revision = js_number(p.get("revision"))
    if revision < highest.get(licence_id, 0):
        return {"valid": False, "reason": "superseded"}
    if last_trusted is not None and at < parse_time(last_trusted) - DAY_MS:
        return {"valid": False, "reason": "clock_behind"}
    if at < parse_time(js_string(p.get("starts"))):
        return {"valid": False, "reason": "not_yet_valid"}

    read_only = False
    if "expires" not in p or at < parse_time(js_string(p.get("expires"))):
        state = "trial" if js_strict_equal(p.get("model"), "trial") else "active"
    elif "graceUntil" in p and at < parse_time(js_string(p.get("graceUntil"))):
        state = "in_grace"
    elif js_strict_equal(p.get("model"), "trial") and js_strict_equal(p.get("trialEnd"), "read_only"):
        state = "trial_ended"
        read_only = True
    else:
        return {"valid": False, "reason": "expired", "state": "expired"}

    result: Dict[str, Any] = {"valid": True, "reason": None, "state": state, "entitlements": p.get("entitlements"), "revision": revision}
    if js_strict_equal(p.get("model"), "trial"):
        result["readOnly"] = read_only
    if "maintenanceUntil" in p:
        result["maintenanceUntil"] = js_string(p.get("maintenanceUntil"))

    if p.get("requiresActivation") is True:
        if activation_token is None:
            return {"valid": False, "reason": "activation_required"}
        activation = parse_token(activation_token, "vya1", keys)
        if activation.error or activation.payload is None:
            return {"valid": False, "reason": activation.error}
        if last_trusted is not None and at < parse_time(last_trusted) - DAY_MS:
            return {"valid": False, "reason": "clock_behind"}
        a = activation.payload
        previous = latest.get(licence_id)
        if previous is not None and parse_time(js_string(a.get("issuedAt"))) < parse_time(previous):
            return {"valid": False, "reason": "superseded"}
        if not js_strict_equal(a.get("licence"), p.get("licence")) or not js_strict_equal(a.get("product"), p.get("product")):
            return {"valid": False, "reason": "activation_mismatch"}
        match = score(a.get("components"), device or {})
        if match < 70:
            return {"valid": False, "reason": "wrong_device", "deviceMatch": match}
        if not js_strict_equal(a.get("state"), "active"):
            return {"valid": False, "reason": js_string(a.get("state"))}
        if "leaseUntil" in a and at >= parse_time(js_string(a.get("leaseUntil"))):
            return {"valid": False, "reason": "lease_expired"}
        if "slot" in a:
            result["slot"] = js_number(a.get("slot"))
        if "limit" in a:
            result["limit"] = js_number(a.get("limit"))
        if "leaseUntil" in a:
            result["leaseUntil"] = js_string(a.get("leaseUntil"))
        if match != 100:
            result["deviceMatch"] = match
    return result


__all__ = ["REASONS", "ParseOutcome", "TrustedKeys", "apply_key_set", "parse_token", "verify_licence"]
