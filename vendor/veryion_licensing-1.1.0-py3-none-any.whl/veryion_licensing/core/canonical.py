"""05 licence format section 2: RFC 8785 with the Veryion limits.

The parser is strict on purpose: floats, exponents, arrays, nulls, non ASCII keys and non NFC strings are refused with
the rule name. A port of sdks/node/src/core/canonical.ts.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Dict, Union

MAX_SAFE_INTEGER = 9_007_199_254_740_991
MAX_PAYLOAD_BYTES = 4_096

JsonValue = Union[str, bool, int, Dict[str, "JsonValue"]]
JsonObject = Dict[str, JsonValue]

RULES = ("array", "null", "fraction", "exponent", "integer_range", "non_ascii_key", "non_nfc", "syntax", "duplicate_key")


class CanonicalError(ValueError):
    def __init__(self, rule: str) -> None:
        super().__init__(rule)
        self.rule = rule


@dataclass
class Parsed:
    value: JsonObject
    duplicate: bool
    # True when the input had no insignificant whitespace and object keys were already ordinal.
    already_canonical: bool


_NUMBER = re.compile(r"-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?")
_HEX4 = re.compile(r"[0-9a-fA-F]{4}")
_SIMPLE = {'"': '"', "\\": "\\", "/": "/", "b": "\b", "f": "\f", "n": "\n", "r": "\r", "t": "\t"}


def _is_ascii(text: str) -> bool:
    return all(ord(ch) < 0x80 for ch in text)


def _join_surrogates(units: list) -> str:
    """JavaScript strings are UTF-16: a \\uD83D\\uDE00 escape pair is one character. Lone surrogates stay as they are."""
    out = []
    index = 0
    while index < len(units):
        code = units[index]
        if 0xD800 <= code <= 0xDBFF and index + 1 < len(units) and 0xDC00 <= units[index + 1] <= 0xDFFF:
            out.append(chr(0x10000 + ((code - 0xD800) << 10) + (units[index + 1] - 0xDC00)))
            index += 2
        else:
            out.append(chr(code))
            index += 1
    return "".join(out)


class _Reader:
    def __init__(self, text: str) -> None:
        self.text = text
        self.pos = 0
        self.duplicate = False
        self.saw_whitespace = False
        self.unsorted = False

    @property
    def already_canonical(self) -> bool:
        return not self.saw_whitespace and not self.unsorted and not self.duplicate

    def _ch(self) -> str:
        return self.text[self.pos] if self.pos < len(self.text) else ""

    def parse_document(self) -> JsonObject:
        self._skip()
        value = self._value()
        self._skip()
        if self.pos != len(self.text):
            raise CanonicalError("syntax")
        if not isinstance(value, dict):
            raise CanonicalError("syntax")
        return value

    def _skip(self) -> None:
        start = self.pos
        while self.pos < len(self.text) and self.text[self.pos] in " \t\n\r":
            self.pos += 1
        if self.pos != start:
            self.saw_whitespace = True

    def _value(self) -> JsonValue:
        ch = self._ch()
        if ch == "{":
            return self._object()
        if ch == "[":
            raise CanonicalError("array")
        if ch == '"':
            return self._string(True)
        if ch == "t" and self.text.startswith("true", self.pos):
            self.pos += 4
            return True
        if ch == "f" and self.text.startswith("false", self.pos):
            self.pos += 5
            return False
        if ch == "n" and self.text.startswith("null", self.pos):
            raise CanonicalError("null")
        return self._number()

    def _object(self) -> JsonObject:
        self.pos += 1
        out: JsonObject = {}
        self._skip()
        if self._ch() == "}":
            self.pos += 1
            return out
        previous = None
        while True:
            self._skip()
            if self._ch() != '"':
                raise CanonicalError("syntax")
            key = self._string(False)
            if not _is_ascii(key):
                raise CanonicalError("non_ascii_key")
            if key in out:
                self.duplicate = True
            if previous is not None and previous > key:
                self.unsorted = True
            previous = key
            self._skip()
            if self._ch() != ":":
                raise CanonicalError("syntax")
            self.pos += 1
            self._skip()
            # Like a JavaScript object: a repeated key keeps its first position and takes the last value.
            out[key] = self._value()
            self._skip()
            nxt = self._ch()
            self.pos += 1
            if nxt == "}":
                return out
            if nxt != ",":
                raise CanonicalError("syntax")

    def _string(self, value_check: bool) -> str:
        self.pos += 1
        units: list = []
        while True:
            if self.pos >= len(self.text):
                raise CanonicalError("syntax")
            ch = self.text[self.pos]
            self.pos += 1
            if ch == '"':
                break
            if ch == "\\":
                esc = self._ch()
                self.pos += 1
                if esc == "u":
                    hexa = self.text[self.pos : self.pos + 4]
                    if not _HEX4.fullmatch(hexa):
                        raise CanonicalError("syntax")
                    units.append(int(hexa, 16))
                    self.pos += 4
                elif esc != "" and esc in _SIMPLE:
                    units.append(ord(_SIMPLE[esc]))
                else:
                    raise CanonicalError("syntax")
            else:
                if ord(ch) < 0x20:
                    raise CanonicalError("syntax")
                units.append(ord(ch))
        out = _join_surrogates(units)
        if value_check:
            try:
                nfc = unicodedata.normalize("NFC", out)
            except ValueError:
                nfc = out
            if nfc != out:
                raise CanonicalError("non_nfc")
        return out

    def _number(self) -> int:
        match = _NUMBER.match(self.text, self.pos)
        if not match:
            raise CanonicalError("syntax")
        self.pos = match.end()
        if match.group(2) is not None:
            raise CanonicalError("fraction")
        if match.group(3) is not None:
            raise CanonicalError("exponent")
        number = int(match.group(0))
        # Number.isSafeInteger: 2^53 and beyond are refused, so are their negatives.
        if abs(number) > MAX_SAFE_INTEGER:
            raise CanonicalError("integer_range")
        return number


def parse_strict(text: str) -> Parsed:
    """Parses a JSON document under the Veryion limits. Repeated keys are reported, the last value is kept."""
    reader = _Reader(text)
    value = reader.parse_document()
    return Parsed(value=value, duplicate=reader.duplicate, already_canonical=reader.already_canonical)


_NEEDS_ESCAPE = re.compile('["\\\\\u0000-\u001f]')
_ESCAPES = {'"': '\\"', "\\": "\\\\", "\b": "\\b", "\f": "\\f", "\n": "\\n", "\r": "\\r", "\t": "\\t"}


def _quote(value: str) -> str:
    if not _NEEDS_ESCAPE.search(value):
        return f'"{value}"'
    out = ['"']
    for ch in value:
        if ch in _ESCAPES:
            out.append(_ESCAPES[ch])
        elif ord(ch) < 0x20:
            out.append("\\u%04x" % ord(ch))
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def canonicalize(value: JsonValue) -> str:
    """Writes a value in canonical form: sorted keys, no whitespace, JCS escaping."""
    if isinstance(value, str):
        return _quote(value)
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, dict):
        # Keys are ASCII (the parser refuses others), so code point order is UTF-16 order.
        return "{" + ",".join(f"{_quote(key)}:{canonicalize(value[key])}" for key in sorted(value)) + "}"
    raise TypeError(f"not a canonical JSON value: {type(value).__name__}")


def canonical_from_text(text: str) -> str:
    """The canonical text of a JSON text, after the strict checks. Raises CanonicalError for a refused rule."""
    return canonicalize(parse_strict(text).value)
