"""Phase 10 06 section 7.2: decide licenceKey or legacyKey on activate. A port of sdks/node/src/legacy.ts."""
from __future__ import annotations

import re
from typing import Dict

from .core.jsvalues import js_trim

_VERYION_KEY = re.compile(r"[A-Z0-9]{3}-[A-Z0-9]{3}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}", re.IGNORECASE | re.ASCII)


def looks_like_licence_key(key: str) -> bool:
    """True when the typed key looks like a Veryion licence key (the Phase 2 form)."""
    return _VERYION_KEY.fullmatch(js_trim(key)) is not None


def activate_key_fields(key: str) -> Dict[str, str]:
    trimmed = js_trim(key)[:200]
    if looks_like_licence_key(trimmed):
        return {"licenceKey": trimmed.upper()}
    return {"legacyKey": trimmed}
