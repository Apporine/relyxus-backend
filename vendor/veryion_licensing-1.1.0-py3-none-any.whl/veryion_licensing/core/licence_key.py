"""05 licence format section 9: licence keys, the Crockford alphabet and a Luhn mod 32 check character. A port of
sdks/node/src/core/licence-key.ts."""
from __future__ import annotations

import re
from typing import Callable

ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"


def check_character(random: str) -> str:
    """The check character for the 11 random characters: Luhn mod 32, starting with factor 2 from the right."""
    factor = 2
    total = 0
    for ch in reversed(random):
        code = ALPHABET.index(ch) * factor
        factor = 1 if factor == 2 else 2
        total += code // 32 + code % 32
    return ALPHABET[(32 - (total % 32)) % 32]


def _luhn_valid(tail: str) -> bool:
    factor = 1
    total = 0
    for ch in reversed(tail):
        code = ALPHABET.index(ch) * factor
        factor = 1 if factor == 2 else 2
        total += code // 32 + code % 32
    return total % 32 == 0


def is_valid_licence_key(text: str) -> bool:
    """A key is valid when its last 12 characters are in the alphabet and the check passes."""
    s = re.sub(r"[ -]", "", text.upper()).replace("I", "1").replace("L", "1").replace("O", "0")
    tail = s[-12:]
    return len(tail) == 12 and all(ch in ALPHABET for ch in tail) and _luhn_valid(tail)


def format_licence_key(product: str, edition: str, twelve: str) -> str:
    """Builds the key text from a product, an edition and 12 characters (11 random and the check)."""
    return f"{product}-{edition}-{twelve[0:4]}-{twelve[4:8]}-{twelve[8:12]}"


def random_characters(next_byte: Callable[[], int], count: int) -> str:
    """32 divides 256, so a random byte modulo 32 is uniform over the alphabet."""
    return "".join(ALPHABET[next_byte() % 32] for _ in range(count))


def generate_licence_key(product: str, edition: str, next_byte: Callable[[], int]) -> str:
    """A key from a random byte source: 11 random characters, then the check character."""
    random = random_characters(next_byte, 11)
    return format_licence_key(product, edition, random + check_character(random))
