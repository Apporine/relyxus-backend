"""The errors of the SDK (09-sdks.md section 1.2). A port of sdks/node/src/errors.ts."""
from __future__ import annotations

from typing import Optional

ERROR_CODES = (
    "invalid_config",
    "not_initialised",
    "invalid_licence_key",
    "licence_not_found",
    "licence_not_active",
    "device_limit_reached",
    "device_unidentifiable",
    "device_mismatch",
    "test_device_in_production",
    "activation_not_found",
    "rate_limited",
    "network_error",
    "timeout",
    "server_error",
    "server_response_invalid",
    "storage_error",
)


class VeryionError(Exception):
    """Every failure the SDK raises. `code` is one of ERROR_CODES.

    Copied from the server answer: `state` for licence_not_active, `limit` and `active` for device_limit_reached.
    """

    def __init__(
        self,
        code: str,
        message: str,
        *,
        status: Optional[int] = None,
        request_id: Optional[str] = None,
        state: Optional[str] = None,
        limit: Optional[int] = None,
        active: Optional[int] = None,
        retry_after_seconds: Optional[float] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status
        self.request_id = request_id
        self.state = state
        self.limit = limit
        self.active = active
        self.retry_after_seconds = retry_after_seconds

    def __repr__(self) -> str:
        return f"VeryionError({self.code!r}, {self.message!r})"
