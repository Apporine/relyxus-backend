"""Phase 10 06 section 7.1: offline request and release files. A port of sdks/node/src/offline.ts."""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional

from .core.base64url import encode_base64url
from .core.canonical import canonicalize
from .errors import VeryionError


@dataclass
class OfflineRequest:
    text: str
    file_name: str
    qr_text: str
    created_at: str


@dataclass
class OfflineRelease:
    text: str
    file_name: str


@dataclass
class OfflineResponse:
    licence: str
    activation: str
    key_set: str


def _compact(value: Mapping[str, Any]) -> Dict[str, Any]:
    """Drops the fields that are not set, as JSON.stringify drops undefined."""
    return {key: (_compact(inner) if isinstance(inner, Mapping) else inner) for key, inner in value.items() if inner is not None}


def release_commit_of(secret: bytes) -> str:
    return encode_base64url(hashlib.sha256(bytes(secret)).digest())


def new_release_secret() -> bytes:
    return os.urandom(32)


def build_offline_request(
    *,
    product: str,
    components: Mapping[str, str],
    sdk: str,
    created_at: str,
    release_secret: bytes,
    licence_key: Optional[str] = None,
    legacy_key: Optional[str] = None,
    app_version: Optional[str] = None,
    nonce: Optional[bytes] = None,
) -> OfflineRequest:
    nonce = os.urandom(16) if nonce is None else nonce
    body: Dict[str, Any] = {
        "components": dict(components),
        "createdAt": created_at,
        "nonce": encode_base64url(nonce),
        "product": product,
        "releaseCommit": release_commit_of(release_secret),
        "sdk": sdk,
    }
    if app_version:
        body["appVersion"] = app_version
    if licence_key:
        body["licenceKey"] = licence_key
    if legacy_key:
        body["legacyKey"] = legacy_key
    text = "vyreq1." + encode_base64url(canonicalize(_compact(body)).encode("utf-8"))
    file_name = f"{licence_key.upper()}.vyreq" if licence_key else "request.vyreq"
    return OfflineRequest(text=text, file_name=file_name, qr_text=text, created_at=created_at)


def build_offline_release(*, activation: str, licence: str, product: str, release_secret: bytes, released_at: str) -> OfflineRelease:
    body = {
        "activation": activation,
        "licence": licence,
        "product": product,
        "releaseSecret": encode_base64url(release_secret),
        "releasedAt": released_at,
    }
    text = "vyrel1." + encode_base64url(canonicalize(body).encode("utf-8"))
    return OfflineRelease(text=text, file_name=f"{licence.upper()}.vyrel")


def split_offline_response(text: str) -> OfflineResponse:
    lines = [line for line in text.replace("\r\n", "\n").split("\n") if len(line) > 0]
    if len(lines) < 3:
        raise VeryionError("server_response_invalid", "The offline response file needs a licence, an activation and a key set line.")
    return OfflineResponse(licence=lines[0], activation=lines[1], key_set=lines[2])
