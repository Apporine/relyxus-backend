"""Fingerprint collection (09-sdks.md section 5). A port of sdks/node/src/fingerprint.ts.

Every component is read in parallel, each command with its own timeout, inside a total budget of 1.5 seconds. Raw values
never leave this module: only the hashes of 05 section 8 are returned.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import threading
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Mapping, Optional

from .core.fingerprint import component_hash

COMPONENTS = ("board", "cpu", "disk", "gpu", "os", "net")

# The Windows queries of section 5, in one PowerShell process: board, system drive, GPU and network. The text is the same
# as the Node and .NET SDKs.
WINDOWS_SCRIPT = " ".join(
    [
        "$ErrorActionPreference='SilentlyContinue';",
        "$part=(Get-CimInstance -Query \"ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='C:'} WHERE AssocClass=Win32_LogicalDiskToPartition\" | Select-Object -First 1).DeviceID;",
        "$disk=(Get-CimInstance -Query \"ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$part'} WHERE AssocClass=Win32_DiskDriveToDiskPartition\" | Select-Object -First 1).SerialNumber;",
        "$board=(Get-CimInstance Win32_BaseBoard).SerialNumber;",
        "$gpu=(Get-CimInstance Win32_VideoController | Where-Object { $_.Name -ne 'Microsoft Basic Display Adapter' } | Select-Object -First 1).Name;",
        "$net=(Get-CimInstance Win32_NetworkAdapter -Filter 'PhysicalAdapter=True' | Sort-Object MACAddress | Select-Object -First 1).MACAddress;",
        "[pscustomobject]@{board=$board;disk=$disk;gpu=$gpu;net=$net} | ConvertTo-Json -Compress",
    ]
)

_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


@dataclass
class Fingerprint:
    components: Dict[str, str] = field(default_factory=dict)
    missing: List[str] = field(default_factory=list)


def _run(args: List[str], timeout_ms: int) -> Optional[str]:
    """The output of a command, or None when it fails, is missing or does not finish in time."""
    try:
        done = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            timeout=timeout_ms / 1000.0,
            creationflags=_NO_WINDOW,
        )
    except Exception:
        return None
    if done.returncode != 0:
        return None
    return done.stdout.decode("utf-8", errors="replace")


def _read_text(path: str) -> Optional[str]:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read().strip()
    except Exception:
        return None


def _parallel(tasks: List[Callable[[], None]]) -> None:
    threads = [threading.Thread(target=task, daemon=True) for task in tasks]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()


def _windows_values(into: Dict[str, Optional[str]]) -> None:
    # The system tools are called by their full path, so a changed PATH cannot hide them.
    root = os.environ.get("SystemRoot", "C:\\Windows")
    reg = os.path.join(root, "System32", "reg.exe")
    powershell = os.path.join(root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")

    def machine_guid() -> None:
        out = _run([reg, "query", "HKLM\\SOFTWARE\\Microsoft\\Cryptography", "/v", "MachineGuid"], 800)
        match = re.search(r"MachineGuid\s+REG_SZ\s+(\S+)", out or "")
        into["os"] = match.group(1) if match else None

    def processor() -> None:
        out = _run([reg, "query", "HKLM\\HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", "/v", "ProcessorNameString"], 800)
        match = re.search(r"ProcessorNameString\s+REG_SZ\s+([^\r\n]+)", out or "")
        name = match.group(1).strip() if match else ""
        count = os.environ.get("NUMBER_OF_PROCESSORS")
        into["cpu"] = f"{name}/{count}" if name and count else None

    def script() -> None:
        out = _run([powershell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", WINDOWS_SCRIPT], 1200)
        try:
            parsed = json.loads((out or "").strip())
        except ValueError:
            return  # Unreadable output: these components are reported missing.
        if not isinstance(parsed, dict):
            return
        for name in ("board", "disk", "gpu", "net"):
            value = parsed.get(name)
            into[name] = value if isinstance(value, str) else None

    _parallel([machine_guid, processor, script])


def _mac_values(into: Dict[str, Optional[str]]) -> None:
    out: Dict[str, Optional[str]] = {}

    def task(key: str, args: List[str], timeout_ms: int) -> Callable[[], None]:
        def go() -> None:
            out[key] = _run(args, timeout_ms)

        return go

    _parallel(
        [
            task("ioreg", ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], 800),
            task("cpu_name", ["sysctl", "-n", "machdep.cpu.brand_string"], 300),
            task("cpu_cores", ["sysctl", "-n", "hw.physicalcpu"], 300),
            task("display", ["system_profiler", "SPDisplaysDataType", "-detailLevel", "mini"], 900),
            task("net", ["ifconfig", "en0"], 300),
        ]
    )
    ioreg = out.get("ioreg") or ""
    uuid = re.search(r'"IOPlatformUUID" = "([^"]+)"', ioreg)
    serial = re.search(r'"IOPlatformSerialNumber" = "([^"]+)"', ioreg)
    chipset = re.search(r"Chipset Model: ([^\n]+)", out.get("display") or "")
    mac = re.search(r"ether ([0-9a-f:]{17})", out.get("net") or "")
    cpu_name = out.get("cpu_name")
    into["os"] = f"mac:{uuid.group(1)}" if uuid else None
    into["board"] = serial.group(1) if serial else None
    into["cpu"] = f"{cpu_name.strip()}/{(out.get('cpu_cores') or '').strip()}" if cpu_name else None
    into["gpu"] = chipset.group(1).strip() if chipset else None
    into["net"] = mac.group(1) if mac else None


def _linux_disk_serial() -> Optional[str]:
    """09 section 5: serial of the disk that holds the root mount, via findmnt and lsblk."""
    root_source = (_run(["findmnt", "-no", "SOURCE", "/"], 600) or "").strip()
    if not root_source:
        return None
    pk_out = (_run(["lsblk", "-no", "PKNAME", root_source], 600) or "").strip()
    pk = (pk_out.split("\n")[0].strip() or root_source.split("/")[-1] or "").strip()
    if not pk:
        return None
    serial = (_run(["lsblk", "-dno", "SERIAL", f"/dev/{pk}"], 600) or "").strip()
    return serial or None


def _linux_values(into: Dict[str, Optional[str]]) -> None:
    # Each value is written into `into` as soon as it is read, so a slow probe later on cannot lose the ones already found.
    value = _read_text("/etc/machine-id")
    into["os"] = value if value is not None else _read_text("/var/lib/dbus/machine-id")
    value = _read_text("/sys/class/dmi/id/board_serial")
    into["board"] = value if value is not None else _read_text("/sys/class/dmi/id/product_uuid")
    cpu_info = _read_text("/proc/cpuinfo")
    model_match = re.search(r"model name\s*:\s*([^\n]+)", cpu_info or "")
    model = model_match.group(1).strip() if model_match else None
    cores = (
        len({f"{m.group(1)}:{m.group(2)}" for m in re.finditer(r"physical id\s*:\s*(\d+)[\s\S]*?core id\s*:\s*(\d+)", cpu_info)})
        if cpu_info
        else 0
    )
    into["cpu"] = f"{model}/{cores}" if model else None
    mac: Optional[str] = None
    try:
        for name in sorted(os.listdir("/sys/class/net")):
            if name == "lo":
                continue
            try:
                os.readlink(f"/sys/class/net/{name}/device")
            except OSError:
                continue
            address = _read_text(f"/sys/class/net/{name}/address")
            if address:
                mac = address
                break
    except OSError:
        mac = None
    into["net"] = mac
    lspci = _run(["lspci", "-mm"], 300)
    gpu = next((line for line in (lspci or "").split("\n") if re.search(r"VGA compatible controller|3D controller", line)), None) if lspci else None
    into["gpu"] = gpu.replace('"', "") if gpu else None
    into["disk"] = _linux_disk_serial()


def raw_values(platform: str, into: Dict[str, Optional[str]]) -> None:
    """The raw values of each component for this platform. A None means the component could not be read."""
    if platform == "win32":
        _windows_values(into)
    elif platform == "darwin":
        _mac_values(into)
    else:
        _linux_values(into)


def _test_hooks(env: Mapping[str, str]) -> Optional[Callable[[str], Optional[str]]]:
    """Test hooks (section 5.1): VY_TEST_DEVICE names the device, VY_TEST_DEVICE_GPU=changed changes its GPU."""
    device = env.get("VY_TEST_DEVICE")
    if not device:
        return None
    changed = env.get("VY_TEST_DEVICE_GPU") == "changed"

    def hook(name: str) -> Optional[str]:
        if name == "gpu" and changed:
            return f"test:{device}:gpu:changed"
        return f"test:{device}:{name}"

    return hook


def collect_fingerprint(
    product: str,
    allow_test_hooks: bool,
    env: Optional[Mapping[str, str]] = None,
    platform: Optional[str] = None,
    budget_ms: int = 1500,
) -> Fingerprint:
    """The six component hashes of this device, with the names missing from it (section 5).

    Test hooks are honoured only when allow_test_hooks is true (the client passes allow_sandbox).
    """
    platform = platform or sys.platform
    env = os.environ if env is None else env
    hooks = _test_hooks(env) if allow_test_hooks else None

    raw: Dict[str, Optional[str]] = {}
    if hooks is None:
        # Whatever is back when the budget ends is used; the rest is reported missing (section 5).
        def probe() -> None:
            try:
                raw_values(platform, raw)
            except Exception:
                pass

        worker = threading.Thread(target=probe, daemon=True, name="veryion-fingerprint")
        worker.start()
        worker.join(budget_ms / 1000.0)
    snapshot = dict(raw)

    components: Dict[str, str] = {}
    missing: List[str] = []
    for name in COMPONENTS:
        value = hooks(name) if hooks else snapshot.get(name)
        digest = component_hash(product, name, value) if value is not None else None
        if digest:
            components[name] = digest
        else:
            missing.append(name)
    return Fingerprint(components=components, missing=missing)
